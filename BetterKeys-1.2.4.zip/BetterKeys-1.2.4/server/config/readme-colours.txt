off             = Disable color background

All possible colors and one example from vanilla (if it has one)

blue			= Blue background, weapon mods in vanilla
yellow			= Golden background, marked keys in vanilla
green			= Dark Green background
red				= Dark Red background
black/grey		= Transparent/void of any background color, default gun background
violet			= Violet/Purple Background, almost all reserve keys in vanilla
orange			= Dark Orange Background, quest items in vanilla
tracerYellow	= Bright Yellow/Golden
tracerGreen		= Bright Green
tracerRed		= Bright Red
default			= White Background, common for a lot of items in vanilla (barter, gear, etc.)